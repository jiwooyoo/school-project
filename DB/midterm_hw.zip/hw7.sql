select * from Ships;
select * from Outcomes;
delete from Ships where (name) in (select ship
from Outcomes
where battle='Surigao Strait' and result='sunk');
select * from Ships;
select * from Outcomes;

select * from Classes;
update Classes set bore=bore*2.5;
update Classes set displacement=displacement/1.1;
select * from Classes;
	
select * from Ships;
select * from Outcomes;
delete from Ships
where (class) in 
(select class
from (select class
      from Ships
      group by class
	  having count(class)<3) T);
select * from Ships;
select * from Outcomes;