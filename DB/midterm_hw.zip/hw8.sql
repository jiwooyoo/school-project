select * from Ships;

alter table Ships 
add company varchar(30)
default 'ShipCompany';

select * from Ships;