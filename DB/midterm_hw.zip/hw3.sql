select class,country
from Classes
where numGuns>=10;

select country
from Classes
where type='bc';

select name as newship
from Ships
where launched>1918;

select name
from Ships
where name like 'R%';