select count(class)
from Classes
where type='bb';

select avg(numGuns)
from Classes
where type='bb';

select class,count(ship)
from Outcomes,Ships
where Outcomes.ship=Ships.name and result='sunk'
group by class;

select battle,sum(numGuns)
from Outcomes,Ships,Classes
where Outcomes.ship=Ships.name and
      Ships.class=Classes.class
group by battle;