# Queries for creating tables, indexes, views

use team14;

# Query Written by. 1615041 Haseon Oh
CREATE TABLE DBCOURSE_MAIN (
	business_id INT,
	name VARCHAR(20) not null,
	type VARCHAR(20),
	address VARCHAR(50),
	phone VARCHAR(20),
	PRIMARY KEY(business_id)
);
CREATE TABLE DBCOURSE_ADDRESS(
	business_id INT,
	address VARCHAR(50),
	floor INT,
	near_station VARCHAR(30),
	PRIMARY KEY(business_id),
	FOREIGN KEY(business_id) REFERENCES DBCOURSE_MAIN(business_id) on delete cascade
);
CREATE TABLE DBCOURSE_TIME(
	business_id INT,
	open_time TIME,
	close_time TIME,
	break_time TIME,
	peak_time TIME,
	PRIMARY KEY(business_id),
	FOREIGN KEY(business_id) REFERENCES DBCOURSE_MAIN(business_id) on delete cascade
);
CREATE TABLE DBCOURSE_MENU(
	business_id INT,
	menu VARCHAR(50),
	price INT,
	menu_grade NUMERIC(2,1),
	PRIMARY KEY(business_id, menu),
	FOREIGN KEY(business_id) REFERENCES DBCOURSE_MAIN(business_id) on delete cascade
);
CREATE TABLE DBCOURSE_EVALUATION(
	business_id INT,
	evaluation NUMERIC(2,1),
	review_num INT,
	TV_appearance_num INT,
	PRIMARY KEY(business_id),
	FOREIGN KEY(business_id) REFERENCEs DBCOURSE_MAIN(business_id) on delete cascade
);
CREATE TABLE DBCOURSE_DELIVERY(
	business_id INT,
	delivery CHAR(2),
	delivery_fee INT,
	min_order_fee INT,
	PRIMARY KEY(business_id),
	FOREIGN KEY(business_id) REFERENCES DBCOURSE_MAIN(business_id) on delete cascade
);
CREATE TABLE DBCOURSE_ROOM(
	business_id INT,
	room_num INT,
	capacity INT,
	PRIMARY KEY(business_id, room_num),
	FOREIGN KEY(business_id) REFERENCES DBCOURSE_MAIN(business_id) on delete cascade
);
CREATE TABLE DBCOURSE_RESERVATION(
	business_id INT,
	date DATETIME,
	name VARCHAR(20),
	person_number INT,
	room_num INT,
	PRIMARY KEY(business_id, date, room_num),
	FOREIGN KEY(business_id, room_num) REFERENCES DBCOURSE_ROOM(business_id, room_num) on delete cascade
);
CREATE TABLE DBCOURSE_INGREDIENT(
	business_id INT,
	menu VARCHAR(50),
	allergy VARCHAR(30),
	origin VARCHAR(10),
	PRIMARY KEY(business_id, menu),
	FOREIGN KEY(business_id, menu) REFERENCES DBCOURSE_MENU(business_id,menu) on delete cascade
);
CREATE TABLE DBCOURSE_REST_ACC(
	business_id INT,
	rest_account INT,
	PRIMARY KEY(business_id),
	FOREIGN KEY(business_id) REFERENCES DBCOURSE_MAIN(business_id) on delete cascade
);
CREATE TABLE DBCOURSE_CUST_ACC(
	customer_id VARCHAR(5),
	cust_account INT,
	PRIMARY KEY(customer_id)
);


/* Query Written 1/4 of each by. 1615041 Haseon Oh, 1615042 Jiwoo Yoo 1615046 Gibbeum Lee, 1615071 YeWon Cheon 
And organized by 1615042 Jiwoo Yoo*/
/* DBCOURSE_MAIN(business_id, name, type, address, phone)*/
insert into DBCOURSE_MAIN values(75042,'Menstu','Japanese','27, Gyeonghuigung 1-gil, Jongno-gu, Seoul','027301379');
insert into DBCOURSE_MAIN values(45663,'Cheiljemyunso','Korean', '89, Saemunan-ro, Jongno-gu, Seoul','027237909');
insert into DBCOURSE_MAIN values(91200,'The466kitchen','Snack','141, Tongil-ro, Seodaemun-gu, Seoul','023931113');
insert into DBCOURSE_MAIN values(35381,'Meitan','Chinese','4, Mapo-daero 24-gil, Mapo-gu, Seoul','050714116688');
insert into DBCOURSE_MAIN values(56877,'Mad for Garlic','Western','17, Jong-ro 3-gil, Jongno-gu, Seoul','0222518320');

insert into DBCOURSE_MAIN values(11223, 'hansinpocha', 'Korean', '20, Seojeong-ro, Pyeongtaek-si, Gyeonggi-do', '0316114786');
insert into DBCOURSE_MAIN values(44566, 'kimnezip', 'Korean', '25, Jungangsijang-ro, Pyeongtaek-si, Gyeonggi-do', '0316663648');
insert into DBCOURSE_MAIN values(78899, 'jajangmaul','Chinese', '20, Seojeong-ro, Pyeongtaek-si, Gyeonggi-do', '05044574404');
insert into DBCOURSE_MAIN values(13579, 'newmaul', 'Korean', '144, Eoulmadang-ro, mapo-gu, Seoul', '023320120');
insert into DBCOURSE_MAIN values(70770, 'Uraeok', 'Korean', '62, Changgyeonggung-ro, jung-gu, Seoul', '0222650151');

insert into DBCOURSE_MAIN values(68487, 'ASHELY', 'etc', '1820, Nambusunhwan-ro, Gwanak-gu, Seoul', '026276823');
insert into DBCOURSE_MAIN values(35639, 'Sangdo gopchang', 'Korean', '357, Sangdo-ro, Dongjak-gu, Seoul', '028213802');
insert into DBCOURSE_MAIN values(82900, 'Piece sushi', 'Japanese', '70, Myeongmul-gil, Seodaemun-gu, Seoul', '023120270');
insert into DBCOURSE_MAIN values(19200, 'The omulet', 'Korean', '40, Sillim-ro 21-gil, Gwanak-gu, Seoul', '07042083400');
insert into DBCOURSE_MAIN values(25713, 'sinhyeon', 'Chinese', '27-1, Kyonggidae-ro, Seodaemun-gu, Seoul', '027208288');

insert into DBCOURSE_MAIN values(38560,'Seobukmeonok','Korean','199-1, Jayang-ro, Gwangjin-gu, Seoul','024578319');
insert into DBCOURSE_MAIN values(17495,'The466kitchen','Western','466, Achasan-ro, Gwangjin-gu, Seoul','024664669');
insert into DBCOURSE_MAIN values(66192,'Marushabu','Korean','633, Cheonho-daero, Gwangjin-gu, Seoul','024543300');
insert into DBCOURSE_MAIN values(40872,'Appletonkatsu','Korean','249, Jayang-ro, Gwangjin-gu, Seoul','024478200');
insert into DBCOURSE_MAIN values(34360,'Lonnielottie','Western','225, Achasan-ro, Gwangjin-gu, Seoul','024987999');

/*DBCOURSE_ADDRESS(business_id,address,floor, near_station)*/

insert into DBCOURSE_ADDRESS values(75042,'27, Gyeonghuigung 1-gil, Jongno-gu, Seoul',1,'Gwanghwamun station');
insert into DBCOURSE_ADDRESS values(45663,'89, Saemunan-ro, Jongno-gu, Seoul',2,'Gwanghwamun station');
insert into DBCOURSE_ADDRESS values(91200,'141, Tongil-ro, Seodaemun-gu, Seoul',1,'Seodaemun station');
insert into DBCOURSE_ADDRESS values(35381,'4, Mapo-daero 24-gil, Mapo-gu, Seoul',3,'Mapo station');
insert into DBCOURSE_ADDRESS values(56877,'17, Jong-ro 3-gil, Jongno-gu, Seoul',3,'Gwanghwamun station');

insert into DBCOURSE_ADDRESS values(11223, '20, Seojeong-ro, Pyeongtaek-si, Gyeonggi-do', 2, 'Seojeongri station');
insert into DBCOURSE_ADDRESS values(44566, '25, Jungangsijang-ro, Pyeongtaek-si, Gyeonggi-do', 1, 'Songtan station');
insert into DBCOURSE_ADDRESS values(78899, '20, Seojeong-ro, Pyeongtaek-si, Gyeonggi-do', 5, 'Songtan station');
insert into DBCOURSE_ADDRESS values(13579, '144, Eoulmadang-ro, mapo-gu, Seoul', 1, 'Hongik university station');
insert into DBCOURSE_ADDRESS values(70770, '62, Changgyeonggung-ro, jung-gu, Seoul', 1, 'Euljiro 4 station');

insert into DBCOURSE_ADDRESS values(68487, '1820, Nambusunhwan-ro, Gwanak-gu, Seoul', 9, 'Seoul univ. station');
insert into DBCOURSE_ADDRESS values(35639, '357, Sangdo-ro, Dongjak-gu, Seoul', 3, 'Soongsil univ. station');
insert into DBCOURSE_ADDRESS values(82900, '70, Myeongmul-gil, Seodaemun-gu, Seoul', -2, 'Sinchon station');
insert into DBCOURSE_ADDRESS values(19200, '40, Sillim-ro 21-gil, Gwanak-gu, Seoul', 1, 'Sinlim station');
insert into DBCOURSE_ADDRESS values(25713, '27-1, Kyonggidae-ro, Seodaemun-gu, Seoul', 1, 'Chungchungro station');

insert into DBCOURSE_ADDRESS values(38560,'199-1, Jayang-ro, Gwangjin-gu, Seoul ',1,'Achasan station');
insert into DBCOURSE_ADDRESS values(17495,'466, Achasan-ro, Gwangjin-gu, Seoul ',1,'Achasan station');
insert into DBCOURSE_ADDRESS values(66192,'633, Cheonho-daero, Gwangjin-gu, Seoul ',3,'Gui station');
insert into DBCOURSE_ADDRESS values(40872,'249, Jayang-ro, Gwangjin-gu, Seoul ',-1,'Gunja station');
insert into DBCOURSE_ADDRESS values(34360,'225, Achasan-ro, Gwangjin-gu, Seoul',2,'Kunkuk University station');

/*DBCOURSE_TIME(business_id,open_time,close_time,break_time,peak_time)*/

insert into DBCOURSE_TIME values(75042,'11:30','22:00','15:00','12:00');
insert into DBCOURSE_TIME values(45663,'11:00','22:00',null,'13:00');
insert into DBCOURSE_TIME values(91200,'11:00','23:00',null,'18:00');
insert into DBCOURSE_TIME values(35381,'11:00','21:30','15:00','19:00');
insert into DBCOURSE_TIME values(56877,'11:30','22:00',null,'18:30');

insert into DBCOURSE_TIME values(11223, '18:00', '06:00', null, '21:00');
insert into DBCOURSE_TIME values(44566, '09:30', '22:00', '11:10', '17:00');
insert into DBCOURSE_TIME values(78899, '00:00', '24:00', null, '18:00');
insert into DBCOURSE_TIME values(13579, '00:00', '24:00', '15:00', '20:00');
insert into DBCOURSE_TIME values(70770, '11:30', '21:30', null, '18:00');

insert into DBCOURSE_TIME values(68487,'11:00','22:00',null,'18:00');
insert into DBCOURSE_TIME values(35639, '15:00', '24:00', null, '21:00');
insert into DBCOURSE_TIME values(82900, '11:30', '22:30', '15:30', '18:00');
insert into DBCOURSE_TIME values(19200, '11:00', '21:00', '15:30','13:00');
insert into DBCOURSE_TIME values(25713, '9:00', '21:00', null, '12:00');

insert into DBCOURSE_TIME values(38560,'11:30','21:30',null,'18:00');
insert into DBCOURSE_TIME values(17495,'11:30','22:00',null,'12:00');
insert into DBCOURSE_TIME values(66192,'11:30','21:30','15:00','19:00');
insert into DBCOURSE_TIME values(40872,'10:00','20:00','15:00','13:00');
insert into DBCOURSE_TIME values(34360,'9:00','21:00','14:00','16:00');

/*DBCOURSE_MENU(business_id,menu,price, menu_grade)*/

insert into DBCOURSE_MENU values(75042,'ColdBuckwheat Noodles',7000,3.0);
insert into DBCOURSE_MENU values(75042,'gyudon',8000,3.0);
insert into DBCOURSE_MENU values(75042,'donkoch ramen',8500,3.5);
insert into DBCOURSE_MENU values(45663,'janchi somyeon',8000,3.5);
insert into DBCOURSE_MENU values(45663,'Shabu Shabu',22000,4.5);
insert into DBCOURSE_MENU values(45663,'jaengban memil',7500,4.0);
insert into DBCOURSE_MENU values(91200,'Tteokbokki',3000,3.5);
insert into DBCOURSE_MENU values(91200,'sundae',3500,4.0);
insert into DBCOURSE_MENU values(91200,'eomuk',2500,4.0);
insert into DBCOURSE_MENU values(35381,'jajangmyeon',6000,4.5);
insert into DBCOURSE_MENU values(35381,'jjamppong',8000,4.3);
insert into DBCOURSE_MENU values(35381,'japchaebap',9000,4.7);
insert into DBCOURSE_MENU values(56877,'Caesar Salad',17900,3.6);
insert into DBCOURSE_MENU values(56877,'Garlicpeno Pasta',19800,3.9);
insert into DBCOURSE_MENU values(56877,'Garlic Snowing Pizza',22800,4.5);

insert into DBCOURSE_MENU values(11223, 'dakbal', 17000, 4.2);
insert into DBCOURSE_MENU values(11223, 'Tteokbokki', 17000, 3.5);
insert into DBCOURSE_MENU values(11223, 'Rolled Omelet', 14000, 3.6);
insert into DBCOURSE_MENU values(44566, 'Budaejjigae', 9000, 4.9);
insert into DBCOURSE_MENU values(78899, 'jajangmyeon', 6000, 3.7);
insert into DBCOURSE_MENU values(78899, 'jjamppong', 7000, 4.0);
insert into DBCOURSE_MENU values(78899, 'ulmyeon', 7000, 3.2);
insert into DBCOURSE_MENU values(78899, 'tangsuyuk', 15000, 3.4);
insert into DBCOURSE_MENU values(13579, 'bulgogi', 9000, 4.5);
insert into DBCOURSE_MENU values(13579, 'Roasted salt', 10000, 4.3);
insert into DBCOURSE_MENU values(13579, 'porkkimchi', 6000, 4.8);
insert into DBCOURSE_MENU values(70770, 'naengmyeon', 13000, 4.7);
insert into DBCOURSE_MENU values(70770, 'bibimnaengmyeon', 13000, 4.3);

insert into DBCOURSE_MENU values(68487, 'Salad bar', 13900, 2.9);
insert into DBCOURSE_MENU values(68487, 'New york stone', 14900, 3.9);
insert into DBCOURSE_MENU values(68487, 'Stone big', 29900, 3.8);
insert into DBCOURSE_MENU values(35639, 'Grilled beef tripe', 16000, 4.0);
insert into DBCOURSE_MENU values(35639, 'Mountain chain tripe', 18000, 3.7);
insert into DBCOURSE_MENU values(82900, 'Mixed sushi', 13000, 4.6);
insert into DBCOURSE_MENU values(82900, 'Special sushi', 16000, 4.6);
insert into DBCOURSE_MENU values(82900, 'Salmon don', 9000, 4.3);
insert into DBCOURSE_MENU values(19200, 'Pork omulet', 7000, 3.6);
insert into DBCOURSE_MENU values(19200, 'Crab omulet', 7000, 3.5);
insert into DBCOURSE_MENU values(19200, 'Pork cutlet omulet', 7000, 2.8);
insert into DBCOURSE_MENU values(25713, 'Seafood jajang', 7000, 4.4);
insert into DBCOURSE_MENU values(25713, 'Fried jjampong', 8000, 4.4);
insert into DBCOURSE_MENU values(25713, 'Mixed meal', 10000, 3.9);

insert into DBCOURSE_MENU values(38560, 'Mul naengmyeon', 8000,4.8);
insert into DBCOURSE_MENU values(38560, 'Bibim naengmyeon', 8000, 4.3);
insert into DBCOURSE_MENU values(38560,'Pork Slices', 10000, 4.5);
insert into DBCOURSE_MENU values(17495,'BLT sandwitch', 13000, 3.9);
insert into DBCOURSE_MENU values(17495,'Steak', 41000, 4.1);
insert into DBCOURSE_MENU values(17495,'lasagna',18000, 4.3);
insert into DBCOURSE_MENU values(66192,'beaf sabu', 15800, 3.5);
insert into DBCOURSE_MENU values(66192,'lamb sabu', 21000, 4.6);
insert into DBCOURSE_MENU values(66192,'marine sabu', 16800, 3.8);
insert into DBCOURSE_MENU values(40872,'tonkazu',7500, 3.0);
insert into DBCOURSE_MENU values(40872,'Bibim naengmyeon',8000, 4.0);
insert into DBCOURSE_MENU values(34360, 'Steak', 22000, 4.2);
insert into DBCOURSE_MENU values(34360,'Carbonara', 11000, 3.9);
insert into DBCOURSE_MENU values(34360,'Gorgonzola pizza', 19000, 3.7);

/*DBCOURSE_EVALUATION(business_id, evaluation, review_num,TV_appearance_num)*/

insert into DBCOURSE_EVALUATION values(75042,3.5,711,0);
insert into DBCOURSE_EVALUATION values(45663,4.3,129,2);
insert into DBCOURSE_EVALUATION values(91200,4.5,532,0);
insert into DBCOURSE_EVALUATION values(35381,4.7,571,3);
insert into DBCOURSE_EVALUATION values(56877,4.5,283,1);

insert into DBCOURSE_EVALUATION values(11223, 3.8, 16, 0);
insert into DBCOURSE_EVALUATION values(44566, 4.2, 628, 5);
insert into DBCOURSE_EVALUATION values(78899, 3.8, 22, 0);
insert into DBCOURSE_EVALUATION values(13579, 4.1, 160, 1);
insert into DBCOURSE_EVALUATION values(70770, 4.1, 1721, 7);

insert into DBCOURSE_EVALUATION values(68487, 3.6, 593, 3);
insert into DBCOURSE_EVALUATION values(35639, 3.9, 186, 2);
insert into DBCOURSE_EVALUATION values(82900, 4.6, 424, 1);
insert into DBCOURSE_EVALUATION values(19200, 3.4, 27, 0);
insert into DBCOURSE_EVALUATION values(25713, 4.4, 40, 0);

insert into DBCOURSE_EVALUATION values(38560, 4.7, 158, 5);
insert into DBCOURSE_EVALUATION values(17495, 4.0, 25, 0);
insert into DBCOURSE_EVALUATION values(66192, 3.8, 110, 2);
insert into DBCOURSE_EVALUATION values(40872, 4.5, 87, 1);
insert into DBCOURSE_EVALUATION values(34360, 4.6, 142, 0);

/*DBCOURSE_DELIVERY(business_id,delivery, delivery_fee, min_order_fee)*/

insert into DBCOURSE_DELIVERY values(75042,'N',null,null);
insert into DBCOURSE_DELIVERY values(45663,'N',null,null);
insert into DBCOURSE_DELIVERY values(91200,'Y',2000,12500);
insert into DBCOURSE_DELIVERY values(35381,'Y',0,5000);
insert into DBCOURSE_DELIVERY values(56877,'N',null,null);

insert into DBCOURSE_DELIVERY values(11223, 'N', null, null);
insert into DBCOURSE_DELIVERY values(44566, 'N', null, null);
insert into DBCOURSE_DELIVERY values(78899, 'Y', 0, 15000);
insert into DBCOURSE_DELIVERY values(13579, 'N', null, null);
insert into DBCOURSE_DELIVERY values(70770, 'N', null, null);

insert into DBCOURSE_DELIVERY values(68487, 'N', null, null);
insert into DBCOURSE_DELIVERY values(35639, 'Y', 0, 14000);
insert into DBCOURSE_DELIVERY values(82900, 'Y', 0, 16000);
insert into DBCOURSE_DELIVERY values(19200, 'Y', 2000, 8000);
insert into DBCOURSE_DELIVERY values(25713, 'Y', 0, 10000);

insert into DBCOURSE_DELIVERY values(38560, 'N', null, null);
insert into DBCOURSE_DELIVERY values(17495, 'Y', 2000, 20000);
insert into DBCOURSE_DELIVERY values(66192, 'Y', null, 20000);
insert into DBCOURSE_DELIVERY values(40872, 'Y', 3000, 10000);
insert into DBCOURSE_DELIVERY values(34360, 'N', null,null);

/*DBCOURSE_ROOM(business_id,room_num,capacity)*/

insert into DBCOURSE_ROOM values(45663,1,8); 
insert into DBCOURSE_ROOM values(45663,2,6); 
insert into DBCOURSE_ROOM values(45663,3,6);
insert into DBCOURSE_ROOM values(35381,1,8);
insert into DBCOURSE_ROOM values(35381,2,8);
insert into DBCOURSE_ROOM values(56877,1,8);
insert into DBCOURSE_ROOM values(56877,2,10);
insert into DBCOURSE_ROOM values(56877,3,8);

insert into DBCOURSE_ROOM values(11223, 1, 8);
insert into DBCOURSE_ROOM values(11223, 2, 8);
insert into DBCOURSE_ROOM values(11223, 3, 12);
insert into DBCOURSE_ROOM values(78899, 1, 12);
insert into DBCOURSE_ROOM values(78899, 2, 12);
insert into DBCOURSE_ROOM values(78899, 3, 20);
insert into DBCOURSE_ROOM values(78899, 4, 16);
insert into DBCOURSE_ROOM values(13579, 1, 20);
insert into DBCOURSE_ROOM values(13579, 2, 8);
insert into DBCOURSE_ROOM values(13579, 3, 8);
insert into DBCOURSE_ROOM values(70770, 1, 12);
insert into DBCOURSE_ROOM values(70770, 2, 8);
insert into DBCOURSE_ROOM values(70770, 3, 8);
insert into DBCOURSE_ROOM values(70770, 4, 4);

insert into DBCOURSE_ROOM values(68487, 1, 2);
insert into DBCOURSE_ROOM values(68487, 2, 4);
insert into DBCOURSE_ROOM values(68487, 3, 4);
insert into DBCOURSE_ROOM values(68487, 4, 10);
insert into DBCOURSE_ROOM values(25713, 1, 8);
insert into DBCOURSE_ROOM values(25713, 2, 8);
insert into DBCOURSE_ROOM values(25713, 3, 4);
insert into DBCOURSE_ROOM values(82900, 1, 4);
insert into DBCOURSE_ROOM values(82900, 2, 4);

insert into DBCOURSE_ROOM values(38560,1,10);
insert into DBCOURSE_ROOM values(38560,2,7);
insert into DBCOURSE_ROOM values(38560,3,5);
insert into DBCOURSE_ROOM values(17495,1,15);
insert into DBCOURSE_ROOM values(17495,2,20);
insert into DBCOURSE_ROOM values(17495,3,10);
insert into DBCOURSE_ROOM values(17495,4,8);
insert into DBCOURSE_ROOM values(17495,5,25);
insert into DBCOURSE_ROOM values(66192,1,5);
insert into DBCOURSE_ROOM values(66192,2,5);
insert into DBCOURSE_ROOM values(34360,1,10);
insert into DBCOURSE_ROOM values(34360,2,4);
insert into DBCOURSE_ROOM values(34360,3,4);

/*DBCOURSE_RESERVATION(business_id,date,name,person_number,room_num)*/

insert into DBCOURSE_RESERVATION values(45663,'18-06-03 13:00','Amy',6,1);
insert into DBCOURSE_RESERVATION values(45663,'18-06-06 18:00','Tom',4,2);
insert into DBCOURSE_RESERVATION values(45663,'18-07-08 13:00','Chris',6,3);
insert into DBCOURSE_RESERVATION values(35381,'18-06-14 14:00','Groot',8,1);
insert into DBCOURSE_RESERVATION values(35381,'18-08-03 12:00','Scarlet',4,2);
insert into DBCOURSE_RESERVATION values(56877,'18-07-24 18:30','Joe',6,1);

insert into DBCOURSE_RESERVATION values(11223, '18-06-15 20:00', 'Kimeunyoung', 10, 3);
insert into DBCOURSE_RESERVATION values(11223, '18-06-22 21:00', 'Parktaemin', 5, 2);
insert into DBCOURSE_RESERVATION values(78899, '18-06-13 18:00', 'Choihaeun', 9, 1);
insert into DBCOURSE_RESERVATION values(78899, '18-06-29 18:00', 'Kimhojun', 7, 1);
insert into DBCOURSE_RESERVATION values(78899, '18-06-29 19:00', 'Minganghyun', 18, 3);
insert into DBCOURSE_RESERVATION values(78899, '18-07-02 19:00', 'Kimjimin', 16, 4);
insert into DBCOURSE_RESERVATION values(13579, '18-06-16 20:00', 'Kimhanna', 7, 3);
insert into DBCOURSE_RESERVATION values(13579, '18-06-16 20:00', 'Minho', 12, 1);
insert into DBCOURSE_RESERVATION values(70770, '18-05-31 13:00', 'Leedo', 6, 3);
insert into DBCOURSE_RESERVATION values(70770, '18-06-10 20:00', 'Kimjion', 4, 4);

insert into DBCOURSE_RESERVATION values (68487, '18-06-03 18:00', 'Byeongcheon Yu', 2, 1);
insert into DBCOURSE_RESERVATION values (68487, '18-06-03 19:00', 'Sohyeon Lee', 4, 3);
insert into DBCOURSE_RESERVATION values (25713, '18-06-02 12:30', 'Haseon Oh', 8, 1);
insert into DBCOURSE_RESERVATION values (82900, '18-06-04 18:00', 'Chaah Kim', 2, 1);

insert into DBCOURSE_RESERVATION values(38560,'18-06-27 15:00','Atom',5, 2);
insert into DBCOURSE_RESERVATION values(38560,'18-06-15 17:00','Nathan',7,1);
insert into DBCOURSE_RESERVATION values(38560,'18-06-15 17:30','Hayoon',4,3);
insert into DBCOURSE_RESERVATION values(17495,'18-05-31 18:00','Minsoo',6,4);
insert into DBCOURSE_RESERVATION values(17495,'18-05-31 20:00','Ohhyun',7,3);
insert into DBCOURSE_RESERVATION values(17495,'18-05-28 16:00','Jihan',18,2);
insert into DBCOURSE_RESERVATION values(17495,'18-05-30 19:30','Ogon',6,4);
insert into DBCOURSE_RESERVATION values(66192,'18-06-08 18:00','Seonmi',5,1);
insert into DBCOURSE_RESERVATION values(66192,'18-06-07 18:00','Libely',3,1);
insert into DBCOURSE_RESERVATION values(66192,'18-06-20 17:30','Sunha',4,2);
insert into DBCOURSE_RESERVATION values(34360,'18-06-03 17:00','Boa',4,3);
insert into DBCOURSE_RESERVATION values(34360,'18-05-22 20:00','Tami',8,1);
insert into DBCOURSE_RESERVATION values(34360,'18-05-29 19:30','Bruce',8,1);

/*DBCOURSE_INGREDIENT(business_id,menu,allergy,origin)*/

insert into DBCOURSE_INGREDIENT values(56877,'Caesar Salad', 'nut products', 'USA');
insert into DBCOURSE_INGREDIENT values(68487, 'Salad bar', 'nut products', 'China');
insert into DBCOURSE_INGREDIENT values(34360,'Carbonara', 'dairy products','Korea');
insert into DBCOURSE_INGREDIENT values(34360,'Gorgonzola pizza','dairy products','Korea');
insert into DBCOURSE_INGREDIENT values(56877,'Garlic Snowing Pizza','dairy products','USA');

#Query Written by. 1615071 Yewon Cheon
/*DBCOURSE_REST_ACC(business_id, rest_account)*/
insert into DBCOURSE_REST_ACC values(75042, 0);
insert into DBCOURSE_REST_ACC values(45663, 0);
insert into DBCOURSE_REST_ACC values(91200, 0);
insert into DBCOURSE_REST_ACC values(35381, 0);
insert into DBCOURSE_REST_ACC values(56877, 0);

insert into DBCOURSE_REST_ACC values(11223, 0);
insert into DBCOURSE_REST_ACC values(44566, 0);
insert into DBCOURSE_REST_ACC values(78899, 0);
insert into DBCOURSE_REST_ACC values(13579, 0);
insert into DBCOURSE_REST_ACC values(70770, 0);

insert into DBCOURSE_REST_ACC values(68487, 0);
insert into DBCOURSE_REST_ACC values(35639, 0);
insert into DBCOURSE_REST_ACC values(82900, 0);
insert into DBCOURSE_REST_ACC values(19200, 0);
insert into DBCOURSE_REST_ACC values(25713, 0);

insert into DBCOURSE_REST_ACC values(38560, 0);
insert into DBCOURSE_REST_ACC values(17495, 0);
insert into DBCOURSE_REST_ACC values(66192, 0);
insert into DBCOURSE_REST_ACC values(40872, 0);
insert into DBCOURSE_REST_ACC values(34360, 0);

/*DBCOURSE_CUST_ACC(customer_id, cust_account)*/
insert into DBCOURSE_CUST_ACC values('67066', 80000);
insert into DBCOURSE_CUST_ACC values('12789', 100000);
insert into DBCOURSE_CUST_ACC values('78787', 70000);
insert into DBCOURSE_CUST_ACC values('86025', 50000);
insert into DBCOURSE_CUST_ACC values('94512', 85000);
insert into DBCOURSE_CUST_ACC values('11111', 93000);

#Query Written by. 1615041 Haseon Oh
create index dbcourse_indexaddress on dbcourse_main(address);
create index dbcourse_indextype on dbcourse_main(type);
create index dbcourse_indexname on dbcourse_main(name);

#Query Written by. 1615046 Gibbeum Lee
create index dbcourse_RVname on DBCOURSE_RESERVATION(name);
create index dbcourse_businessId on dbcourses_main(business_id);
create view dbcourse_InfoMenu as
select *
from dbcourse_menu natural left outer join dbcourse_ingredient;

#Query Written by. 1615041 Haseon Oh
create view dbcourse_nameview as
(select name, address, phone,open_time, peak_time, close_time, break_time, evaluation, review_num, TV_appearance_num,business_id
from (DBCOURSE_MAIN natural join DBCOURSE_TIME) join DBCOURSE_EVALUATION using(business_id) );

create view dbcourse_addressview as
(select dbcourse_main.address, name, phone, type, near_station, open_time, close_time, break_time, evaluation, dbcourse_main.business_id
from dbcourse_main
left join DBCOURSE_ADDRESS on DBCOURSE_MAIN.business_id=DBCOURSE_ADDRESS.business_id
left join DBCOURSE_TIME on DBCOURSE_MAIN.business_id = DBCOURSE_TIME.business_id
left join DBCOURSE_EVALUATION on DBCOURSE_MAIN.business_id = DBCOURSE_EVALUATION.business_id);

create view dbcourse_typeview as 
(select type, name, phone, DBCOURSE_MAIN.address, floor, near_station, open_time, close_time, break_time, evaluation, dbcourse_main.business_id
from dbcourse_main 
left join DBCOURSE_ADDRESS on DBCOURSE_MAIN.business_id=DBCOURSE_ADDRESS.business_id
left join DBCOURSE_TIME on DBCOURSE_MAIN.business_id = DBCOURSE_TIME.business_id
left join DBCOURSE_EVALUATION on DBCOURSE_MAIN.business_id = DBCOURSE_EVALUATION.business_id);