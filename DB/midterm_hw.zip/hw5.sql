select T.country,T.numGuns
from Classes as T
where not exists (
select T.country
from Classes as S
where T.numGuns<S.numGuns );

select class
from Ships
where (name) in (select ship
               from Outcomes
			   where result='damaged');