create table Classes(
       class varchar(30),
	   type char(2),
	   country varchar(20),
	   numGuns int,
	   bore numeric(8,2),
	   primary key(class));
	   
create table Ships(
       name varchar(30),
	   class varchar(30),
	   launched int,
	   primary key(name),
	   foreign key(class) references Classes(class));
	   
create table Battles(
       name varchar(30),
	   beginDate DATE,
	   endDate DATE,
	   primary key(name));
	   
create table Outcomes(
       ship varchar(30),
	   battle varchar(30),
	   result varchar(10),
	   primary key(ship,battle),
	   foreign key(ship) references Ships(name) on delete cascade,
	   foreign key(battle) references Battles(name) on delete cascade);
	   
describe Classes;
describe Ships;
describe Battles;
describe Outcomes;
	   