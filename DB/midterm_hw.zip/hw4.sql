select displacement,name
from Ships,Classes
where displacement>35000 and Classes.class=Ships.class
order by displacement,name;

(select name from Ships where class='Renown' or launched<1919)
union
(select ship from Outcomes where battle='North Atlantic');

select ship from Outcomes where result='damaged' and
(ship) in (select ship from Outcomes group by ship having count(ship)>1); 

select ship,date_format(beginDate,'%m-%Y'),date_format(endDate,'%m-%Y')
from Battles,Outcomes
where year(beginDate)>=1942 and year(endDate)<=1943
      and Battles.name=Outcomes.battle;
