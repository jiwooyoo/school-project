# Queries for dropping all tables and data from database
# Query Written by. 1615071 Yewon Cheon 
# modified by. 1615046 Gibbeum Lee
use team14;
drop view dbcourse_InfoMenu;
drop view dbcourse_nameview;
drop view dbcourse_addressview;
drop view dbcourse_typeview;

drop table dbcourse_reservation;
drop table dbcourse_room;
drop table dbcourse_ingredient;
drop table dbcourse_menu;
drop table dbcourse_delivery;
drop table dbcourse_evaluation;
drop table dbcourse_address;
drop table dbcourse_time;
drop table DBCOURSE_REST_ACC;
drop table DBCOURSE_CUST_ACC;
drop table dbcourse_main;